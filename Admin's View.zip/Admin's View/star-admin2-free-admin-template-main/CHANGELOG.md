# CHANGELOG

## V2.0.0 

- Bootstrap5


## V1.0.0 

- Initial release
